<?php $__env->startSection('page_title'); ?>
    Dashboard - Home-Services
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    Hello Form Dashboard
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\xampp\htdocs\laravel Final Project Important File\Homeservices\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>