<?php $__env->startSection('main-contant'); ?>
    <h2>This is body</h2>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.tamplete', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\xampp\htdocs\laravel Final Project Important File\Homeservices\resources\views/admin/admindashboard.blade.php ENDPATH**/ ?>