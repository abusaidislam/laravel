<h1>Customer Dashboard</h1>
<?php /**PATH H:\xampp\htdocs\laravel Final Project Important File\Homeservices\resources\views/customer/dashboard.blade.php ENDPATH**/ ?>