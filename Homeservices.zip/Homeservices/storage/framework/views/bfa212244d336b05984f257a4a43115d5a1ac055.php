<?php $__env->startSection('page_title'); ?>
    Dashboard - Home-Services
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <!-- Bootstrap Table with Header - Light -->
    <div class="container-xxl flex-grow-1 container-p-y">
        <h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light">Page/</span> All Category</h4>
        <div class="card">
            <h5 class="card-header" style="margin-bottom: -40px">Available Category Infromation</h5>
            <div class="row ">
                <div class="col-11 text-end my-2">
                    <a href="<?php echo e(route('addcategory')); ?>" class="btn btn-primary">Add Category</a>
                </div>

            </div>
            <!--       message       -->
            <?php if(session()->has('message')): ?>
                <div class="alert alert-success">
                    <?php echo e(session()->get('message')); ?>

                </div>
            <?php endif; ?>
            <!--       message       -->
            <div class="table-responsive text-nowrap">
                <table class="table">
                    <thead class="table-light">
                        <tr>
                            <th>Id</th>
                            <th>Category Name</th>
                            <th>Image</th>
                            <th>Slug</th>
                            <th>Services Count</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody class="table-border-bottom-0">
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($item->id); ?></td>
                                <td><?php echo e($item->category_name); ?></td>

                                <td> <img style="height: 50px" src="<?php echo e(asset($item->categroy_image)); ?>" alt="">
                                </td>
                                <td><?php echo e($item->slug); ?></td>
                                <td>0</td>
                                <td>
                                    <a href="" class="btn btn-primary">Edit</a>
                                    <a href=""class="btn btn-warning">Delete</a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                    </tbody>
                </table>
            </div>
        </div>
        <!-- Bootstrap Table with Header - Light -->
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\xampp\htdocs\laravel Final Project Important File\Homeservices\resources\views/admin/allcategory.blade.php ENDPATH**/ ?>